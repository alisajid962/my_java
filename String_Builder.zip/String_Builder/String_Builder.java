import java.sql.SQLOutput;
import java.util.*;
class Bank{
        private StringBuilder name;
    Bank(String Name){
//        Scanner sc = new Scanner(System.in);
//        String input = sc.nextLine();
         name  =  new StringBuilder(Name);
    }
    void setName(String a ){
        name = new StringBuilder(a);
    }
    StringBuilder getName(){
        return name;
    }
    StringBuilder getFormattedName(){
        String temp = name.toString();
        String first;
        name.setLength(0);

        String [] strarr =temp.split("\\s+");
        for (String temp1: strarr){
             temp1 = temp1.trim();
             first = temp1.substring(0,1).toUpperCase()+temp1.substring(1).toLowerCase();
            name.append(first).append(" ");
        }

//        name = new StringBuilder(temp);
        return name;
    }
    StringBuilder reversedName(){
        return name.reverse();
    }
    void Displayinfo(){
        System.out.println("-------------------");
        System.out.println("Formatted Name: "+getFormattedName());
        System.out.println("Reversed Name: "+reversedName());
    }
}
public class String_Builder {
    public static void main(String[] args) {
        Bank c1 = new Bank("ali sajid");
        c1.Displayinfo();
        Bank c2 = new Bank("hassan ahmed");
        c2.Displayinfo();

    }
}
