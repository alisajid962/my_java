public class practice {
    public static void main(String[] args) {
        StringBuilder msg = new StringBuilder("Hello ALi");
//        System.out.println(msg.append(" Sajid"));
//        System.out.println(msg.append(9));
//        System.out.println(msg.delete(0,6));
//        System.out.println(msg.deleteCharAt(4));
//        System.out.println(msg.indexOf(" "));
//        System.out.println(msg.lastIndexOf("i"));
//        System.out.println(msg.insert(5," Mr."));
//        System.out.println(msg.reverse());
//        System.out.println(msg.replace(0,5,"Hey"));
//        System.out.println(msg.substring(0,5));
    }
}
